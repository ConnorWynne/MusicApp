Resonance Android resource replacements
========================================

This bundle was prepared from the approved Resonance.png master artwork.

Contents:
- res/drawable*/splash.png: splash artwork resized to the exact dimensions supplied for your current project.
- res/mipmap-*/ic_launcher.png and ic_launcher_round.png: standard launcher PNGs.
- res/mipmap-*/ic_launcher_foreground.png: inset artwork for adaptive icons.

Important:
1. Back up android/app/src/main/res before copying.
2. Copy the contents of this bundle's res folder into android/app/src/main/res, preserving folder names.
3. Do NOT copy or replace mipmap-anydpi-v26 XML files or values/ic_launcher_background.xml.
4. Your adaptive icon background should remain #050720.
5. The adaptive foreground uses the approved complete artwork inset to reduce clipping. Check on-device appearance after build.
